/* SeñasAI · interfaz. Las funciones detectarSena() y mostrarResultado() son los puntos
   donde se conectará el modelo de IA; mientras tanto no se muestra ningún resultado. */
const $ = id => document.getElementById(id);
const video = $("video"), startCamera = $("startCamera"), stopCamera = $("stopCamera"),
  cameraPlaceholder = $("cameraPlaceholder"), cameraStatus = $("cameraStatus"), cameraStatusText = $("cameraStatusText"),
  cameraMsg = $("cameraMsg"), detectingIndicator = $("detectingIndicator"), detectedSign = $("detectedSign"),
  translationText = $("translationText"), confidence = $("confidence"), aiStatusTitle = $("aiStatusTitle"),
  aiStatusText = $("aiStatusText"), historyContainer = $("historyContainer"), emptyHistory = $("emptyHistory");
let stream = null, detectionInterval = null, ultimaTraduccion = "", historial = [];
const SIGN_EMPTY = '<svg class="ic"><use href="#i-hand"/></svg><span>Esperando una seña…</span>';
const MSG_LISTO = "Listo para conectar el modelo.", TXT_LISTO = " Cuando exista, aquí verás cada seña con su traducción.";

/* Navegación móvil */
const navToggle = $("navToggle"), navMenu = $("navMenu");
navToggle.addEventListener("click", () => {
  const abierto = navMenu.classList.toggle("open");
  navToggle.setAttribute("aria-expanded", abierto);
});
navMenu.addEventListener("click", e => { if (e.target.tagName === "A") { navMenu.classList.remove("open"); navToggle.setAttribute("aria-expanded", "false"); } });

/* Cámara */
function estadoCamara(activa) {
  cameraStatus.classList.toggle("on", activa);
  cameraStatusText.textContent = activa ? "Cámara activa" : "Cámara apagada";
  video.style.display = activa ? "block" : "none";
  cameraPlaceholder.style.display = activa ? "none" : "flex";
  detectingIndicator.hidden = !activa;
  startCamera.disabled = activa; stopCamera.disabled = !activa;
}

async function iniciarCamara() {
  cameraMsg.textContent = "";
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    cameraMsg.textContent = "Este navegador no permite usar la cámara. Abre la página desde http://localhost o con HTTPS.";
    return;
  }
  try {
    stream = await navigator.mediaDevices.getUserMedia({ video: { width: { ideal: 1280 }, height: { ideal: 720 }, facingMode: "user" }, audio: false });
    video.srcObject = stream;
    estadoCamara(true);
    aiStatusTitle.textContent = "Cámara activa, modelo sin conectar.";
    aiStatusText.lastChild.textContent = " Por ahora no se reconocen señas.";
    iniciarDeteccion();
  } catch (error) {
    console.error("Error al acceder a la cámara:", error);
    cameraMsg.textContent = "No se pudo acceder a la cámara. Permite el acceso en tu navegador y vuelve a intentarlo.";
  }
}

function detenerCamara() {
  if (stream) { stream.getTracks().forEach(t => t.stop()); stream = null; }
  video.srcObject = null;
  estadoCamara(false);
  aiStatusTitle.textContent = MSG_LISTO;
  aiStatusText.lastChild.textContent = TXT_LISTO;
  detenerDeteccion();
}

function iniciarDeteccion() { detectionInterval = setInterval(detectarSena, 500); }
function detenerDeteccion() { clearInterval(detectionInterval); detectionInterval = null; }

function detectarSena() {
  /* AQUÍ SE INTEGRARÁ EL MODELO:
     const r = await modelo.predict(video);
     mostrarResultado(r.sena, r.traduccion, r.confianza); */
}

function mostrarResultado(sena, traduccion, porcentaje) {
  ultimaTraduccion = traduccion;
  detectedSign.className = "sign hit";
  detectedSign.innerHTML = '<svg class="ic"><use href="#i-hand"/></svg><span></span>';
  detectedSign.lastChild.textContent = sena;
  translationText.textContent = traduccion;
  confidence.textContent = Math.round(porcentaje) + "%";
  aiStatusTitle.textContent = "Seña reconocida.";
  agregarHistorial(traduccion, porcentaje);
}

/* Historial */
function agregarHistorial(texto, porcentaje) {
  if (historial[0] && historial[0].texto === texto) return;
  const hora = new Date().toLocaleTimeString("es-MX", { hour: "2-digit", minute: "2-digit" });
  historial.unshift({ texto, confianza: Math.round(porcentaje), hora });
  if (historial.length > 20) historial.pop();
  mostrarHistorial();
}

function mostrarHistorial() {
  historyContainer.textContent = "";
  if (!historial.length) { historyContainer.appendChild(emptyHistory); return; }
  historial.forEach(item => {
    const fila = document.createElement("div");
    fila.className = "history-item";
    const izq = document.createElement("div");
    const palabra = document.createElement("div"); palabra.className = "history-word"; palabra.textContent = item.texto;
    const hora = document.createElement("div"); hora.className = "history-time"; hora.textContent = item.hora;
    izq.append(palabra, hora);
    const conf = document.createElement("div"); conf.className = "history-confidence"; conf.textContent = item.confianza + "%";
    fila.append(izq, conf);
    historyContainer.appendChild(fila);
  });
}

function limpiarTraduccion() {
  ultimaTraduccion = "";
  detectedSign.className = "sign"; detectedSign.innerHTML = SIGN_EMPTY;
  translationText.innerHTML = '<span class="ph">Esperando una seña para traducir.</span>';
  confidence.textContent = "--%";
  aiStatusTitle.textContent = MSG_LISTO; aiStatusText.lastChild.textContent = TXT_LISTO;
}

function escucharTraduccion() {
  if (!ultimaTraduccion) { cameraMsg.textContent = "Todavía no hay una traducción para escuchar."; return; }
  if (!("speechSynthesis" in window)) { cameraMsg.textContent = "Tu navegador no soporta la función de voz."; return; }
  cameraMsg.textContent = "";
  speechSynthesis.cancel();
  const voz = new SpeechSynthesisUtterance(ultimaTraduccion);
  voz.lang = "es-MX"; voz.rate = 0.9;
  speechSynthesis.speak(voz);
}

function limpiarHistorial() { historial = []; mostrarHistorial(); }

startCamera.addEventListener("click", iniciarCamara);
stopCamera.addEventListener("click", detenerCamara);
$("clearButton").addEventListener("click", limpiarTraduccion);
$("speakButton").addEventListener("click", escucharTraduccion);
$("clearHistory").addEventListener("click", limpiarHistorial);
window.addEventListener("beforeunload", detenerCamara);

/* Texto a señas */
const userText = $("userText"), characterCount = $("characterCount"), textInputMessage = $("textInputMessage"),
  userTextResult = $("userTextResult"), userTextPreview = $("userTextPreview"), signStage = $("signStage");
const STAGE_VACIO = '<svg class="ic ic-xl"><use href="#i-hand"/></svg><p>El video de la seña aparecerá aquí cuando agregues un texto.</p>';

userText.addEventListener("input", () => {
  characterCount.textContent = userText.value.length + " / 1000 caracteres";
  textInputMessage.textContent = "";
});

/* Videos de YouTube por palabra. Para agregar una seña: escribe la palabra en minúsculas y sin acentos
   y pega el enlace del video. Si el video tiene varias señas, agrega &t=SEGUNDO (y opcional &end=SEGUNDO). */
const VIDEOS = {
  "lunes": "https://youtu.be/ghEDIa_xig0",
  "martes": "https://youtu.be/d3yvC-_3_Ww",
  "miercoles": "https://youtu.be/Qy4aa2yWYEQ",
  "jueves": "https://youtu.be/rP3xI-R9BDI",
  "viernes": "https://youtu.be/pPpWCZlsQjQ",
  "sabado": "https://youtu.be/GXfetqowaI8",
  "domingo": "https://youtu.be/wVFuoyU6WqQ",
  "1": "https://youtu.be/MI8R55ONNaI",
  "2": "https://youtu.be/RGkVjIEKNjg",
  "3": "https://youtu.be/8Z7Myi5CTPU",
  "4": "https://youtu.be/axEPHWTbU8Q",
  "5": "https://youtu.be/t65uA06IO88",
  "6": "https://youtu.be/ZG-YrUhh9Rc",
  "7": "https://youtu.be/amndzAkUnJ4",
  "8": "https://youtu.be/q59d0y4nFgY",
  "9": "https://youtu.be/1FvbAnNiPJI",
  "10": "https://youtu.be/VlzAy7H2Bhg",
  "hijo": "https://youtu.be/PLOzw0iD2c0",
  "hija": "https://youtu.be/UI1_RzOcF9Y",
  "papa": "https://youtu.be/k8fs-F6Oldw",
  "mama": "https://youtu.be/QziTWIvcPHs",
  "esposa": "https://youtu.be/S3oGGlrNTpA",
  "esposo": "https://youtu.be/OAbgMjmfnZ8",
  "enero": "https://youtu.be/acAJEgM8mng",
  "febrero": "https://youtu.be/ixGCUHfztPw",
  "marzo": "https://youtu.be/-qLcosnyrlQ",
  "abril": "https://youtu.be/NvgTIcQmkDw",
  "mayo": "https://youtu.be/P4giWbh9HWo",
  "junio": "https://youtu.be/f-njC2GQyqs",
  "julio": "https://youtu.be/E19W7S2K3c4",
  "agosto": "https://youtu.be/0r9JMo_OLsY",
  "septiembre": "https://youtu.be/xF7P57XNy70",
  "octubre": "https://youtu.be/nG-GUxgNoiY",
  "noviembre": "https://youtu.be/r7-Y3TM-QV4",
  "diciembre": "https://youtu.be/FBPrb5bE7bY",
  "como": "https://youtu.be/Ys2a7WHJVHw",
  "por que": "https://youtu.be/MXlKKizZH-U",
  "cuantos": "https://youtu.be/65ylDHTv1SA",
  "para que": "https://youtu.be/bnMf4NTjwH8",
  "nariz": "https://youtu.be/xUhxlcZ7pSY",
  "ojo": "https://youtu.be/8V55RhKvA-A",
  "pie": "https://youtu.be/uMrDWul1gEE",
  "panza": "https://youtu.be/6Os0Xdc9NX8",
  "cuello": "https://youtu.be/owyR0Fxx4fg",
  "brazo": "https://youtu.be/XL6e3RQpvvw",
  "boca": "https://youtu.be/VZ6LSOrI8YI",
  "codo": "https://youtu.be/kFVsC9sDU6A",
  "mal": "https://youtu.be/XsOex1P1yZ0",
  "bien": "https://youtu.be/rMfHE1t2ccM",
  "si": "https://youtu.be/hmx-3t0pd1g",
  "no": "https://youtu.be/Z3ASchMaksU",
  "confundido": "https://youtu.be/xm1yCrVK33A",
  "hola": "https://youtu.be/wRti8LmGwMQ",
  "uno": "https://youtu.be/MI8R55ONNaI",
  "dos": "https://youtu.be/RGkVjIEKNjg",
  "tres": "https://youtu.be/8Z7Myi5CTPU",
  "cuatro": "https://youtu.be/axEPHWTbU8Q",
  "cinco": "https://youtu.be/t65uA06IO88",
  "seis": "https://youtu.be/ZG-YrUhh9Rc",
  "siete": "https://youtu.be/amndzAkUnJ4",
  "ocho": "https://youtu.be/q59d0y4nFgY",
  "nueve": "https://youtu.be/1FvbAnNiPJI",
  "diez": "https://youtu.be/VlzAy7H2Bhg",
  "porque": "https://youtu.be/MXlKKizZH-U"
};
const quitarAcentos = s => s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9ñ ]/g, "").trim();
function videoDe(palabra) {
  const url = VIDEOS[quitarAcentos(palabra)];
  if (!url) return null;
  const m = url.match(/(?:v=|youtu\.be\/|embed\/|shorts\/)([\w-]{11})/); if (!m) return null;
  const t = url.match(/[?&](?:t|start)=(\d+)/), e = url.match(/[?&]end=(\d+)/);
  return { id: m[1], inicio: t ? +t[1] : 0, fin: e ? +e[1] : 0 };
}
/* Vocabulario del modelo (150 palabras) + las que solo tienen video */
const VOCAB = [["hola", "Saludos"], ["hospital", "Salud"], ["sí", "Básicas"], ["duro", "Adjetivos"], ["lunes", "Días"], ["perro", "Animales"], ["cansado", "Emociones"], ["ayer", "Tiempo"], ["yo", "Pronombres"], ["nosotros", "Pronombres"], ["beber", "Verbos"], ["ambulancia", "Salud"], ["infección", "Salud"], ["ojo", "Cuerpo"], ["no", "Básicas"], ["pregunta", "Básicas"], ["duda", "Básicas"], ["bien", "Básicas"], ["mal", "Básicas"], ["suave", "Adjetivos"], ["normal", "Adjetivos"], ["frío", "Adjetivos"], ["caliente", "Adjetivos"], ["mejor", "Adjetivos"], ["peor", "Adjetivos"], ["estresado", "Adjetivos"], ["rápido", "Adjetivos"], ["lento", "Adjetivos"], ["martes", "Días"], ["miércoles", "Días"], ["jueves", "Días"], ["viernes", "Días"], ["sábado", "Días"], ["domingo", "Días"], ["gato", "Animales"], ["camarón", "Animales"], ["pollo", "Animales"], ["abeja", "Animales"], ["confundido", "Emociones"], ["ahora", "Tiempo"], ["hoy", "Tiempo"], ["mañana", "Tiempo"], ["nunca", "Tiempo"], ["siempre", "Tiempo"], ["diario", "Tiempo"], ["mamá", "Personas"], ["papá", "Personas"], ["esposo", "Personas"], ["esposa", "Personas"], ["hijo", "Personas"], ["hija", "Personas"], ["enero", "Meses"], ["febrero", "Meses"], ["marzo", "Meses"], ["abril", "Meses"], ["mayo", "Meses"], ["junio", "Meses"], ["julio", "Meses"], ["agosto", "Meses"], ["septiembre", "Meses"], ["octubre", "Meses"], ["noviembre", "Meses"], ["diciembre", "Meses"], ["1", "Números"], ["2", "Números"], ["3", "Números"], ["4", "Números"], ["5", "Números"], ["6", "Números"], ["7", "Números"], ["8", "Números"], ["9", "Números"], ["10", "Números"], ["cómo", "Preguntas"], ["cuántos", "Preguntas"], ["para qué", "Preguntas"], ["por qué", "Preguntas"], ["cocinar", "Verbos"], ["recibir", "Verbos"], ["estudiar", "Verbos"], ["interpretar", "Verbos"], ["ir", "Verbos"], ["no ver", "Verbos"], ["dormir", "Verbos"], ["pelear", "Verbos"], ["trabajar", "Verbos"], ["descansar", "Verbos"], ["comer", "Verbos"], ["correr", "Verbos"], ["caminar", "Verbos"], ["jarabe", "Salud"], ["virus", "Salud"], ["aborto", "Salud"], ["accidente", "Salud"], ["doctor", "Salud"], ["enfermera", "Salud"], ["enfermero", "Salud"], ["paciente", "Salud"], ["enfermo", "Salud"], ["terapia", "Salud"], ["pastillas", "Salud"], ["inyección", "Salud"], ["contagiar", "Salud"], ["revisar", "Salud"], ["calentura", "Salud"], ["cáncer", "Salud"], ["infarto", "Salud"], ["lesión", "Salud"], ["embarazo", "Salud"], ["sangre", "Salud"], ["gripa", "Salud"], ["garganta", "Salud"], ["tos", "Salud"], ["débil", "Salud"], ["huesos", "Salud"], ["farmacia", "Salud"], ["emergencia", "Salud"], ["inflamación", "Salud"], ["análisis", "Salud"], ["coronavirus", "Salud"], ["cita", "Salud"], ["dolor", "Salud"], ["fractura", "Salud"], ["urgencia", "Salud"], ["orina", "Salud"], ["popó", "Salud"], ["mareo", "Salud"], ["vómito", "Salud"], ["convulsiones", "Salud"], ["gases", "Salud"], ["diarrea", "Salud"], ["moco", "Salud"], ["sed", "Salud"], ["nariz", "Cuerpo"], ["oreja", "Cuerpo"], ["boca", "Cuerpo"], ["cuello", "Cuerpo"], ["hombro", "Cuerpo"], ["espalda", "Cuerpo"], ["brazo", "Cuerpo"], ["codo", "Cuerpo"], ["muñeca", "Cuerpo"], ["mano", "Cuerpo"], ["panza", "Cuerpo"], ["cintura", "Cuerpo"], ["pene", "Cuerpo"], ["vagina", "Cuerpo"], ["piernas", "Cuerpo"], ["rodilla", "Cuerpo"], ["tobillo", "Cuerpo"], ["pie", "Cuerpo"]];  /* [palabra, categoría] */
const urlBusqueda = p => "https://www.youtube.com/results?search_query=" + encodeURIComponent("seña de " + p + " LSM lengua de señas mexicana");

function reproducir(palabra, v, visor) {
  visor.textContent = "";
  if (v) {
    const f = document.createElement("iframe");
    f.src = "https://www.youtube.com/embed/" + v.id + "?rel=0&autoplay=1&start=" + v.inicio + (v.fin ? "&end=" + v.fin : "");
    f.allow = "autoplay; encrypted-media; picture-in-picture; fullscreen"; f.allowFullscreen = true;
    f.referrerPolicy = "strict-origin-when-cross-origin"; f.title = "Seña de " + palabra; f.className = "sign-video";
    visor.appendChild(f);
  } else {
    const p = document.createElement("p"); p.className = "stage-note";
    p.textContent = "Todavía no tengo el video de “" + palabra + "”. ";
    const a = document.createElement("a"); a.href = urlBusqueda(palabra); a.target = "_blank"; a.rel = "noopener"; a.textContent = "Buscarla en YouTube";
    p.appendChild(a); visor.appendChild(p);
  }
}

$("showUserText").addEventListener("click", () => {
  const texto = userText.value.trim();
  if (!texto) { textInputMessage.textContent = "Escribe una palabra o una oración antes de continuar."; userText.focus(); return; }
  userTextPreview.textContent = texto;
  userTextResult.hidden = false;
  signStage.textContent = ""; signStage.classList.add("has");
  const sueltas = texto.split(/\s+/).filter(p => quitarAcentos(p)), palabras = [];
  for (let i = 0; i < sueltas.length; i++) {   /* junta “por qué”, “para qué”… si existen como frase */
    const par = sueltas[i] + " " + (sueltas[i + 1] || "");
    if (sueltas[i + 1] && videoDe(par)) { palabras.push(par); i++; } else palabras.push(sueltas[i]);
  }
  const visor = document.createElement("div"); visor.className = "sign-viewer";
  const fichas = document.createElement("div"); fichas.className = "tok-row";
  let primera = null;
  palabras.forEach((p, i) => {
    const v = videoDe(p);
    const ficha = document.createElement("button"); ficha.type = "button"; ficha.className = "tok" + (v ? "" : " tok-miss");
    ficha.innerHTML = '<svg class="ic"><use href="#i-hand"/></svg>'; ficha.append(p);
    ficha.addEventListener("click", () => {
      fichas.querySelectorAll(".tok").forEach(x => x.classList.remove("cur")); ficha.classList.add("cur");
      reproducir(p, v, visor);
    });
    fichas.appendChild(ficha);
    if (!primera) primera = ficha;
  });
  signStage.append(fichas, visor);
  if (palabras.length > 1) { const n = document.createElement("p"); n.className = "stage-note"; n.textContent = "Toca cada palabra para ver su seña."; signStage.appendChild(n); }
  if (primera) primera.click();
});

$("clearUserText").addEventListener("click", () => {
  userText.value = ""; userTextPreview.textContent = ""; userTextResult.hidden = true;
  characterCount.textContent = "0 / 1000 caracteres"; textInputMessage.textContent = "";
  signStage.classList.remove("has"); signStage.innerHTML = STAGE_VACIO;
  userText.focus();
});

/* Vocabulario con categorías */
const vocGrid = $("vocGrid"), vocSearch = $("vocSearch"), vocCat = $("vocCat");
const CATEGORIAS = [...new Set(VOCAB.map(v => v[1]))];
vocCat.add(new Option("Todas las categorías", ""));
CATEGORIAS.forEach(c => vocCat.add(new Option(c, c)));
function pintarVocab() {
  const q = quitarAcentos(vocSearch.value), cat = vocCat.value;
  const lista = VOCAB.filter(([p, c]) => (!cat || c === cat) && (!q || quitarAcentos(p).includes(q)))
    .map(([p, c]) => ({ p, c, v: !!videoDe(p) }));
  lista.sort((a, b) => b.v - a.v);   /* primero las que ya tienen video */
  vocGrid.textContent = "";
  lista.forEach(({ p, c, v }) => {
    const b = document.createElement("button"); b.type = "button"; b.className = "vw" + (v ? " has-video" : "");
    if (v) { const f = document.createElement("span"); f.className = "film"; f.textContent = "🎬"; f.title = "Tiene video"; b.appendChild(f); }
    const n = document.createElement("b"); n.textContent = p;
    const s = document.createElement("small"); s.textContent = c;
    b.append(n, s);
    b.addEventListener("click", () => {
      userText.value = p; characterCount.textContent = p.length + " / 1000 caracteres"; textInputMessage.textContent = "";
      $("showUserText").click();
      document.getElementById("signOutput").scrollIntoView({ behavior: "smooth", block: "nearest" });
    });
    vocGrid.appendChild(b);
  });
  if (!lista.length) { const e = document.createElement("p"); e.className = "stage-note"; e.textContent = "No encontré esa palabra."; vocGrid.appendChild(e); }
}
vocSearch.addEventListener("input", pintarVocab); vocCat.addEventListener("change", pintarVocab);
pintarVocab();

/* Pestañas del traductor */
const tabs = [...document.querySelectorAll('[role="tab"]')];
function activarPestana(tab, enfocar) {
  tabs.forEach(t => {
    const activa = t === tab;
    t.setAttribute("aria-selected", activa);
    t.tabIndex = activa ? 0 : -1;
    $(t.getAttribute("aria-controls")).hidden = !activa;
  });
  if (enfocar) tab.focus();
}
tabs.forEach((tab, i) => {
  tab.addEventListener("click", () => activarPestana(tab));
  tab.addEventListener("keydown", e => {
    const d = { ArrowRight: 1, ArrowLeft: -1 }[e.key];
    if (d) { e.preventDefault(); activarPestana(tabs[(i + d + tabs.length) % tabs.length], true); }
    else if (e.key === "Home") { e.preventDefault(); activarPestana(tabs[0], true); }
    else if (e.key === "End") { e.preventDefault(); activarPestana(tabs[tabs.length - 1], true); }
  });
});
